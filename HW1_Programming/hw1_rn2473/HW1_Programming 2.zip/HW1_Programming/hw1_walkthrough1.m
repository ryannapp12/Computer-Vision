%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Introducing MATLAB (adapted from http://www.cns.nyu.edu/~eero and
% http://www.cs.dartmouth.edu/~farid/teaching/cs88/MATLAB.intro.html)

% We encourage you to run each line of this script to make sure you
% understand what each command works.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (1) Help and basics

% The symbol "%" is used in front of a comment.

% To get help type "help" (will give list of help topics) or "help topic".

% For documentation of a command, type "help command" (prints in command 
% window) or "doc command" (opens documentation browser).

% If you don't know the exact name of the topic or command you are looking
% for, type "lookfor keyword" (e.g., "lookfor regression").

% When writing a long MATLAB statement that exceeds a single row use ... to
% continue statement to next row.

% When using the command line, a ";" at the end means MATLAB will not
% display the result. If ";" is omitted then MATLAB will display the 
% result.

% Use the up-arrow to recall commands without retyping them (and down arrow
% to go forward in commands).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (2) Objects in MATLAB -- the basic objects in MATLAB are scalars,
% vectors, and matrices...

N = 5                  % a scalar
v = [1 0 0]            % a row vector
v = [1; 2; 3]          % a column vector
v = v'                 % transpose vector (row to column or column to row)
v = [1:.5:3]           % a vector in a specified range: [start:end] 
                       %     (inclusive) or [start:stepsize:end]
v = pi*[-8:2:8]/4
v = []                 % empty vector


m = [1 2 3; 4 5 6]     % a matrix: semicolon separates rows
m = zeros(2, 3)        % a 2x3 matrix of zeros
v = ones(1, 3)         % a 1x3 matrix of ones
m = eye(3)             % 3x3 identity matrix
m = rand(3)            % random 3x3 matrix with values in [0, 1]
v = rand(3, 1)         % random 3-element vector with values in [0, 1] 
v = randn(3, 1)        % normally distributed values

load matrix_data       % read data from a file, which contains the matrix:
                       %     2  3  4
                       %     5  6  7
                       %     1  2  3
matrix_data

v = [1 2 3];           
v(3)                   % access 3rd element of vector (index starts at 1)

m = [1 2 3; 4 5 6]
m(1, 3)                % access matrix element at row 1, column 3
m(2, :)                % access the entire 2nd row as a vector
m(:, 3)                % access the entire 3rd column as a vector

size(m)                % size of a matrix
size(m, 1)             % number of rows
size(m, 2)             % number of columns

m1 = zeros(size(m))    % create a new matrix with size of m

who                    % list of variables
whos                   % list/size/type of variables


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (3) Simple operations on vectors and matrices

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (A) Pointwise (element by element) operations:

% addition of vectors/matrices and multiplication by a scalar are done
% "element by element"
a = [1 2 3 4];         % vector
2 * a                  % scalar multiplication
a / 4                  % scalar division
b = [5 6 7 8];         % vector
a + b                  % pointwise vector addition
a - b                  % pointwise vector addition
a .^ 2                 % pointise vector squaring (note .)
a .* b                 % pointwise vector multiplication (note .)
a ./ b                 % pointwise vector division (note .)

log([1 2 3 4])           % pointwise arithmetic operation
round([1.5 2; 2.2 3.1])  % pointwise arithmetic operation


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (B) Vector Operations (no for loops needed)
% Built-in MATLAB functions operate on vectors, if a matrix is given,
% then the function operates on each column of the matrix

a = [1 4 6 3]          % vector
sum(a)                 % sum of vector elements
mean(a)                % mean of vector elements
var(a)                 % variance
std(a)                 % standard deviation
max(a)                 % maximum


a = [1 2 3; 4 5 6]     % matrix
a(:)                   % vectorized version of the matrix
mean(a)                % mean of each column
max(a)                 % max of each column    
max(max(a))            % max of entire matrix
max(a(:))              % max of entire matrix

a(1, 3) = 9            % set single element
a(:, 2) = 99           % set entire 2nd column to same scalar
a(:, 1) = ones(2, 1)   % set entire 1st column to vector of same size


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (C) Matrix Operations:

[1 2 3] * [4 5 6]'     % 1x3 row vector times 3x1 column vector results in
                       % single scalar, also known as dot/inner product

[1 2 3]' * [4 5 6]     % 3x1 column vector times 1x3 row vector results in
                       % 3x3 matrix, also known as outer product

a = rand(3, 2)         % 3x2 matrix
b = rand(2, 4)         % 2x4 matrix
c = a * b              % 3x4 matrix

a = [1 2; 3 4; 5 6]    % 3x2 matrix
b = [5 6 7];           % 1x3 vector
b * a                  % matrix multiply
a' * b'                % matrix multiply


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%(4) Saving your work

save mysession         % creates mysession.mat with all variables
save mysession a b     % save only variables a and b

clear                  % clear all variables
clear a b              % clear variables a and b

load mysession         % load session
a
b


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%(5) Relations and control statements

% Example: given a vector v, create a new vector with values equal to
% v if they are greater than 0, and equal to 0 if they less than or
% equal to 0.


v = [3 5 -2 5 -1 0]    % 1: FOR LOOPS
u = zeros(size(v));    % initialize
for i = 1:size(v,2)    % size(v,2) is the number of columns
    if (v(i) > 0)
        u(i) = v(i); 
    end
end

v = [3 5 -2 5 -1 0]    % 2: NO FOR LOOPS (indices)
u2 = zeros(size(v));   % initialize
ind = find(v > 0)      % index into > 0 elements 
u2(ind) = v(ind)       % set same indices in u to >0 elements of v

v = [3 5 -2 5 -1 0]    % 3: NO FOR LOOPS (mask)
u3 = zeros(size(v));   % initialize
mask = v > 0           % create logical (binary) mask of same size as v: 1
                       %     where condition is true, 0 elsewhere
u3(mask) = v(mask)     % set same indices in u to > 0 elements of v
u3(v > 0) = v(v > 0)   % same but without explicit mask variable
u3(v < 0) = -1         % can also set multiple values to a scalar


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%(6) Creating functions using m-files:
% Functions in MATLAB are written in m-files. Create a file called 
% 'thres.m' and put the following 4 lines (without the % prefixes):

% function ret = thres(v)
% u = zeros(size(v));
% ind = find(v > 0)  % no semicolon: display output
% u(ind) = v(ind);
% ret = u         

v = [3 5 -2 5 -1 0];
u = thres(v)           % call from command window


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%(7) Plotting 

x = [0 1 2 3 4];
plot(x);
plot(x, 2*x);
axis([0 8 0 8]);

x = pi*[-24:24]/24;
plot(x, sin(x));
xlabel('radians');
ylabel('sin value');
title('sin plot');
disp('Put cursor where you want text and click mouse');
gtext('Hello World!');

figure;                % multiple functions in separate graphs
subplot(1, 2, 1);
plot(x, sin(x));
axis square;
subplot(1, 2, 2);
plot(x, 2.*cos(x));
axis square;

figure;                % multiple functions in single graph
plot(x, sin(x));
hold on;               % tells MATLAB to draw on top of current plot
plot(x, 2.*cos(x), '--');
legend('sin', 'cos');
hold off;

figure;                % matrices as images
m = rand(64, 64);
imagesc(m)
colormap gray;
axis image
axis off;              % don't show axes


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%(8) Working with images and the MATLAB Image Processing Toolbox

[I, map] = imread('trees.tif');  % load a MATLAB-supplied image from the
                                 %     default path. .tif files are
                                 %     automatically read as indexed images
                                 %     images with a colormap in the range
                                 %     [0, 1]

figure
imshow(I,map)          % display it as indexed image w/colormap

I2 = ind2gray(I,map);  % convert to a grayscale (non-indexed) image
figure
imshow(I2)

figure
imagesc(I2)            % display image data matrix as a scaled image using 
                       %     the default colormap, where low values are
                       %     dark blue and high values are yellow. The
                       %     range of the colormap is determined from the
                       %     minimum and maximum values of the data
axis('image')          % make displayed aspect ratio proportional to image
                       %     dimensions (i.e. enforce square pixels); this
                       %     is the default for imshow but not imagesc
colorbar               % turn on color bar to show color scale
colormap('jet')        % switch to "jet" colormap
colormap('gray')       % switch to grayscale colormap

figure
colormap('gray')
axis('image')
imagesc(I2, [0 127])   % scale colormap so pixels from 0 to 127 span the
                       %     full map; brighter pixels are shown as the
                       %     maximum map value
colorbar

Id = im2double(I2);    % convert to double with range [0, 1]
figure
imshow(Id)             % imshow works for floating-point images as well; it
                       %     assumes the range is [0, 1]
Id2 = Id*2;
imshow(Id2)            % all pixels >= 1 are shown at max brightness
imagesc(Id2)           % imagesc automatically scales to min and max
colormap('gray')
imshow(rescale(Id2))   % rescale scales matrix to [0, 1]


I = imread('football.jpg');       % read a JPEG image into 3D array

figure
imshow(I)
disp('Use the mouse to select a rectangle in the image.')
disp(['If you get an "Image is too small" warning, try selecting a '...
    'larger rectangle.'])
rect = getrect;                   % select rectangle
I2 = imcrop(I,rect);              % crop
I2 = rgb2gray(I2);                % convert cropped image to grayscale
imagesc(I2)                       % scale data to use full colormap between
                                  %     min and max values in I2
colormap('gray')
colorbar                          % turn on color bar
impixelinfo                       % display pixel values interactively
truesize                          % display at resolution of one screen
                                  %     pixel per image pixel
truesize(2*size(I2))              % display at resolution of two screen
                                  %     pixels per image pixel

I3 = imresize(I2, 0.5, 'bil');    % resize by 50% using bilinear 
                                  %     interpolation
imshow(I3)

I3 = imrotate(I2, 45, 'bil', 'crop');  % rotate 45 degrees and crop to
                                       %     original size
imshow(I3)

I4 = double(I2);                  % cast from uint8 to double to allow math
                                  %     operations
imagesc(I4.^2)                    % display squared image (pixel-wise)
imagesc(log(I4))                  % display log of image

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
