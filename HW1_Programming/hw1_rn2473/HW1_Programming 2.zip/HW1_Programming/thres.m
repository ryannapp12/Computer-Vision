function ret = thres(v)
u = zeros(size(v));
ind	= find(v > 0)  % no semicolon: display output
u(ind) = v(ind);
ret = u;
