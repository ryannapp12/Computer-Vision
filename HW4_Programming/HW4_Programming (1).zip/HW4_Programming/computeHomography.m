function H_3x3 = computeHomography(src_pts_nx2, dest_pts_nx2)
