function stitched_img = stitchImg(varargin)
