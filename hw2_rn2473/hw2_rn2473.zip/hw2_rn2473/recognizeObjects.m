function output_img = recognizeObjects(orig_img, labeled_img, obj_db)
