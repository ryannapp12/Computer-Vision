function hough_img = generateHoughAccumulator(img, theta_num_bins, rho_num_bins)
