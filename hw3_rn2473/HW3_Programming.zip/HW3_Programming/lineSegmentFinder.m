function cropped_line_img = lineSegmentFinder(orig_img, hough_img, hough_threshold)
